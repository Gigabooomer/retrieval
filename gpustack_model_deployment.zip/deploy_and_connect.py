import os
import paramiko
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Get credentials from .env
SSH_USER = os.getenv("SSH_USER")
SSH_SERVER_IP = os.getenv("SSH_SERVER_IP")
SSH_PRIVATE_KEY = os.getenv("SSH_PRIVATE_KEY")
MODEL_NAME = os.getenv("MODEL_NAME")
MODEL_PORT = os.getenv("MODEL_PORT", "8000")

# Connect to GPUstack server via SSH
print(f"Connecting to {SSH_SERVER_IP} as {SSH_USER}...")

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(SSH_SERVER_IP, username=SSH_USER, key_filename=SSH_PRIVATE_KEY)

# Command to deploy the model using vLLM
DEPLOY_COMMAND = f"""
pip install vllm torch transformers accelerate --quiet &&
nohup python3 -m vllm.entrypoints.api_server \
    --model {MODEL_NAME} \
    --host 0.0.0.0 \
    --port {MODEL_PORT} \
    --gpu-memory-utilization 0.9 > model.log 2>&1 &
"""

print("Deploying model on remote server...")
stdin, stdout, stderr = ssh.exec_command(DEPLOY_COMMAND)
stdout.channel.recv_exit_status()  # Wait for execution to complete

print(f"Model {MODEL_NAME} is deployed on port {MODEL_PORT}.")

# Setup SSH Port Forwarding (Tunneling) for Local Access
print(f"Setting up SSH tunneling: Localhost:{MODEL_PORT} → {SSH_SERVER_IP}:{MODEL_PORT}")
LOCAL_TUNNEL_COMMAND = f"ssh -i {SSH_PRIVATE_KEY} -L {MODEL_PORT}:localhost:{MODEL_PORT} {SSH_USER}@{SSH_SERVER_IP}"
os.system(LOCAL_TUNNEL_COMMAND)

ssh.close()
