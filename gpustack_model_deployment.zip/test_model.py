import os
import time
import requests
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Get model settings from .env
MODEL_PORT = os.getenv("MODEL_PORT", "8000")
MODEL_NAME = os.getenv("MODEL_NAME", "DeeSeek/deeseek-r1-distill-qwen-7b")

# Define the API URL
API_URL = f"http://localhost:{MODEL_PORT}/generate"

# Define test prompts
test_prompts = [
    "Tell me a joke about AI.",
    "What is the meaning of life?",
    "Explain quantum computing in simple terms.",
    "Write a short poem about the future of technology.",
    "Summarize the benefits of AI in healthcare."
]

# Define max tokens for each test
MAX_TOKENS = 100  # Adjust as needed

# Test Results Storage
results = []

# Start testing
print(f"🔍 Running performance test on model: {MODEL_NAME}\n")

for prompt in test_prompts:
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "max_tokens": MAX_TOKENS
    }

    try:
        print(f"▶️ Testing prompt: \"{prompt[:30]}...\"")

        start_time = time.time()  # Start timer
        response = requests.post(API_URL, json=payload, headers={"Content-Type": "application/json"})
        end_time = time.time()  # End timer

        latency = end_time - start_time  # Calculate latency

        if response.status_code == 200:
            result = response.json()
            generated_text = result.get("text", "").strip()
            generated_tokens = len(generated_text.split())  # Approximate token count
            tokens_per_sec = generated_tokens / latency if latency > 0 else 0

            results.append({
                "prompt": prompt,
                "latency (s)": round(latency, 3),
                "generated tokens": generated_tokens,
                "tokens/sec": round(tokens_per_sec, 2)
            })

            print(f"✅ Response received in {round(latency, 3)}s | Tokens: {generated_tokens} | Speed: {round(tokens_per_sec, 2)} tokens/sec\n")

        else:
            print(f"❌ Test Failed! Error {response.status_code}: {response.text}\n")

    except requests.exceptions.RequestException as e:
        print(f"❌ Model Test Failed! Could not reach the API.\nError: {str(e)}\n")

# Display summary
if results:
    import pandas as pd

    df = pd.DataFrame(results)
    print("\n📊 Test Summary:")
    print(df)
