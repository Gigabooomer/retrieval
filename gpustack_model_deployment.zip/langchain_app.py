import os
import requests
from dotenv import load_dotenv
from langchain.llms.base import LLM
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Load environment variables
load_dotenv()
MODEL_PORT = os.getenv("MODEL_PORT", "8000")
MODEL_NAME = os.getenv("MODEL_NAME")

# Define Custom LLM Class for Direct API Calls to vLLM
class CustomLLM(LLM):
    def _call(self, prompt, stop=None):
        url = f"http://localhost:{MODEL_PORT}/generate"
        headers = {"Content-Type": "application/json"}
        payload = {
            "model": MODEL_NAME,
            "prompt": prompt,
            "max_tokens": 200
        }

        response = requests.post(url, headers=headers, json=payload)
        result = response.json()
        return result.get("text", "").strip()

    @property
    def _identifying_params(self):
        return {"endpoint": f"http://localhost:{MODEL_PORT}/generate"}

    @property
    def _llm_type(self):
        return "custom_vllm"

# Create a prompt template
prompt = PromptTemplate(input_variables=["question"], template="Q: {question}\nA:")

# Create LLM Chain
llm = CustomLLM()
chain = LLMChain(llm=llm, prompt=prompt)

# Ask a question
question = "Tell me a joke about AI."
response = chain.run(question)
print("AI Response:", response)
