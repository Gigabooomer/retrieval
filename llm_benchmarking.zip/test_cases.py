# test_cases.py

TEST_CASES = {
    "general_knowledge": [
        {"query": "What is the capital of France?", "expected": "Paris"},
        {"query": "Solve 5 + 7", "expected": "12"},
        {"query": "Explain the theory of relativity in simple terms.", "expected": ""},
    ],
    "math": [
        {"query": "Integrate x^2 + 3x + 5", "expected": ""},
        {"query": "Solve for x: 2x + 3 = 11", "expected": "x = 4"},
    ],
    "coding": [
        {"query": "Write a Python function to reverse a string", "expected": "def reverse_string"},
        {"query": "What does the 'map' function do in Python?", "expected": "applies a function to all elements"},
    ]
}

def get_test_cases(category="general_knowledge"):
    """Returns test cases based on category."""
    return TEST_CASES.get(category, TEST_CASES["general_knowledge"])
