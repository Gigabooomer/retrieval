# models.py
from langchain.llms import HuggingFacePipeline
from transformers import pipeline

# Load local models
def load_local_model(model_name):
    """Loads a locally deployed model via Hugging Face pipeline."""
    return HuggingFacePipeline.from_model_id(model_name)

MODELS = {
    "mistral-7b": load_local_model("mistralai/Mistral-7B-Instruct-v0.1"),
    "qwen": load_local_model("Qwen/Qwen-7B-Chat"),
    "llama3": load_local_model("meta-llama/Meta-Llama-3-8B"),
}

def get_model(model_name):
    """Returns the selected model."""
    if model_name not in MODELS:
        raise ValueError(f"Model {model_name} not found!")
    return MODELS[model_name]
