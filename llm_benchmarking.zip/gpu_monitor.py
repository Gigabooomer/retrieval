# gpu_monitor.py
import time
import pynvml
import threading

# Initialize NVIDIA Management Library
pynvml.nvmlInit()
gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)  # Use first GPU

monitoring = False
gpu_metrics = []

def get_gpu_metrics():
    """Fetch GPU stats."""
    gpu_util = pynvml.nvmlDeviceGetUtilizationRates(gpu_handle).gpu  # % GPU usage
    memory_info = pynvml.nvmlDeviceGetMemoryInfo(gpu_handle)
    memory_used = memory_info.used / (1024 ** 2)  # Convert bytes to MB
    power_usage = pynvml.nvmlDeviceGetPowerUsage(gpu_handle) / 1000  # Convert mW to W
    return gpu_util, memory_used, power_usage

def monitor_gpu(interval=0.5):
    """Continuously monitors GPU metrics during inference."""
    global monitoring, gpu_metrics
    gpu_metrics = []
    while monitoring:
        gpu_metrics.append(get_gpu_metrics())
        time.sleep(interval)
